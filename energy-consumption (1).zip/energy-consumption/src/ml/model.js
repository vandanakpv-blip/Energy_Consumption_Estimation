import * as tf from '@tensorflow/tfjs'
import { FEATURE_COLUMNS } from './preprocessing'

/**
 * Simple feed-forward regression network.
 * Input(6 numeric features + season(1) + holiday(1) = 8)
 * -> Dense(16, relu) -> Dense(8, relu) -> Dense(1, linear)
 */
export function buildModel(inputSize) {
  const model = tf.sequential()

  model.add(
    tf.layers.dense({
      inputShape: [inputSize],
      units: 16,
      activation: 'relu',
    }),
  )
  model.add(
    tf.layers.dense({
      units: 8,
      activation: 'relu',
    }),
  )
  model.add(
    tf.layers.dense({
      units: 1,
      activation: 'linear',
    }),
  )

  model.compile({
    optimizer: tf.train.adam(0.01),
    loss: 'meanSquaredError',
  })

  return model
}

export const INPUT_SIZE = FEATURE_COLUMNS.length + 2 // + season + holiday
