// Numeric feature columns used as model inputs, in a fixed order.
export const FEATURE_COLUMNS = [
  'previous_usage',
  'temperature',
  'humidity',
  'hour',
  'day_of_week',
  'previous_period_usage',
]

export const SEASON_CODES = { Spring: 0, Summer: 1, Autumn: 2, Winter: 3 }
export const SEASON_LABELS = ['Spring', 'Summer', 'Autumn', 'Winter']

export const VALID_RANGES = {
  previous_usage: [0, 100],
  temperature: [-20, 60],
  humidity: [0, 100],
  hour: [0, 23],
  day_of_week: [0, 6],
  previous_period_usage: [0, 100],
}

export function encodeYesNo(value) {
  return value === 'Yes' ? 1 : 0
}

export function encodeSeason(value) {
  return SEASON_CODES[value] ?? 0
}

/** Computes per-feature min/max (and for the target) from training rows only. */
export function computeStats(rows) {
  const stats = {}
  FEATURE_COLUMNS.forEach((col) => {
    const values = rows.map((r) => r[col])
    stats[col] = { min: Math.min(...values), max: Math.max(...values) }
  })
  const targets = rows.map((r) => r.energy_consumption)
  stats.energy_consumption = { min: Math.min(...targets), max: Math.max(...targets) }
  return stats
}

export function normalizeValue(value, min, max) {
  if (max === min) return 0
  return (value - min) / (max - min)
}

export function denormalizeValue(value, min, max) {
  return value * (max - min) + min
}

/** Shuffles and splits rows into 80% train / 20% test, deterministically. */
export function trainTestSplit(rows, testRatio = 0.2, seed = 42) {
  const shuffled = seededShuffle(rows, seed)
  const testSize = Math.max(1, Math.round(shuffled.length * testRatio))
  const testRows = shuffled.slice(0, testSize)
  const trainRows = shuffled.slice(testSize)
  return { trainRows, testRows }
}

function seededShuffle(array, seed) {
  const result = [...array]
  let s = seed
  const random = () => {
    s = (s * 9301 + 49297) % 233280
    return s / 233280
  }
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1))
    ;[result[i], result[j]] = [result[j], result[i]]
  }
  return result
}

export function validateInput(field, value) {
  const [min, max] = VALID_RANGES[field] || [0, 100]
  if (value === '' || value === null || value === undefined || Number.isNaN(Number(value))) {
    return 'Enter a number.'
  }
  const num = Number(value)
  if (num < min || num > max) {
    return `Must be between ${min} and ${max}.`
  }
  return null
}
