import React, { useMemo, useRef, useState } from 'react'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceDot,
} from 'recharts'
import PredictionResult from '../components/PredictionResult'
import ChartCard from '../components/ChartCard'
import ReportButton from '../components/ReportButton'
import { VALID_RANGES, validateInput, SEASON_LABELS } from '../ml/preprocessing'
import { predictConsumption, categorize } from '../ml/training'
import { hourlyAverages } from '../services/dataset'

const DAY_LABELS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

const DEFAULTS = {
  previous_usage: 3,
  temperature: 25,
  humidity: 55,
  hour: 18,
  day_of_week: 0,
  season: 'Summer',
  holiday: 'No',
  previous_period_usage: 3,
}

const NUMERIC_FIELDS = [
  ['previous_usage', 'Previous Energy Usage (kWh)', 0.1],
  ['temperature', 'Temperature (°C)', 0.5],
  ['humidity', 'Humidity (%)', 1],
  ['hour', 'Hour', 1],
  ['previous_period_usage', 'Previous Period Usage (kWh)', 0.1],
]

export default function EstimateConsumption({ modelStatus, trainingResult, rows }) {
  const [form, setForm] = useState(DEFAULTS)
  const [errors, setErrors] = useState({})
  const [result, setResult] = useState(null)
  const resultRef = useRef(null)
  const chartRef = useRef(null)

  const modelReady = modelStatus === 'ready' && trainingResult
  const hourly = useMemo(() => (rows ? hourlyAverages(rows) : []), [rows])

  const handleNumber = (field, value) => setForm((f) => ({ ...f, [field]: Number(value) }))
  const handleSelect = (field, value) => setForm((f) => ({ ...f, [field]: value }))

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!modelReady) return

    const nextErrors = {}
    NUMERIC_FIELDS.forEach(([field]) => {
      const err = validateInput(field, form[field])
      if (err) nextErrors[field] = err
    })
    const dayErr = validateInput('day_of_week', form.day_of_week)
    if (dayErr) nextErrors.day_of_week = dayErr

    setErrors(nextErrors)
    if (Object.keys(nextErrors).length > 0) {
      setResult(null)
      return
    }

    try {
      const value = predictConsumption(trainingResult.model, trainingResult.stats, form)
      setResult({ value, category: categorize(value), input: { ...form } })
    } catch (err) {
      setResult(null)
      setErrors({ form: 'Something went wrong generating a prediction. Try adjusting the inputs.' })
    }
  }

  const chartData = useMemo(() => {
    if (!result) return hourly
    return hourly.map((h) => (h.hour === `${String(result.input.hour).padStart(2, '0')}:00`
      ? { ...h, predicted: result.value }
      : h))
  }, [hourly, result])

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-black/5 p-6 space-y-5">
        {NUMERIC_FIELDS.map(([field, label, step]) => {
          const [min, max] = VALID_RANGES[field]
          return (
            <div key={field}>
              <div className="flex justify-between text-sm mb-1">
                <label htmlFor={field} className="text-ink/70">{label}</label>
                <span className="text-ink font-medium">{form[field]}</span>
              </div>
              <input
                id={field}
                type="range"
                min={min}
                max={max}
                step={step}
                value={form[field]}
                onChange={(e) => handleNumber(field, e.target.value)}
                className="w-full accent-volt"
              />
              {errors[field] && <p className="text-xs text-red-600 mt-1">{errors[field]}</p>}
            </div>
          )
        })}

        <div className="grid grid-cols-3 gap-4 pt-1">
          <div>
            <label className="text-sm text-ink/70 block mb-1">Day of Week</label>
            <select
              value={form.day_of_week}
              onChange={(e) => handleNumber('day_of_week', e.target.value)}
              className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
            >
              {DAY_LABELS.map((d, i) => <option key={d} value={i}>{d}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm text-ink/70 block mb-1">Season</label>
            <select
              value={form.season}
              onChange={(e) => handleSelect('season', e.target.value)}
              className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
            >
              {SEASON_LABELS.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm text-ink/70 block mb-1">Holiday</label>
            <select
              value={form.holiday}
              onChange={(e) => handleSelect('holiday', e.target.value)}
              className="w-full border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
            >
              <option value="No">No</option>
              <option value="Yes">Yes</option>
            </select>
          </div>
        </div>

        {errors.form && <p className="text-sm text-red-600">{errors.form}</p>}

        <button
          type="submit"
          disabled={!modelReady}
          className="w-full bg-ink text-white rounded-md py-2.5 text-sm font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-ink/90 transition-colors"
        >
          {modelReady ? 'Estimate Consumption' : 'Preparing model…'}
        </button>
      </form>

      <div className="space-y-5">
        {result ? (
          <>
            <PredictionResult innerRef={resultRef} value={result.value} category={result.category} input={result.input} />
            <ChartCard
              innerRef={chartRef}
              title="Prediction in Context"
              description="Estimated value against typical usage for that hour"
            >
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
                  <CartesianGrid stroke="#e8ebe9" vertical={false} />
                  <XAxis dataKey="hour" tick={{ fontSize: 10 }} interval={2} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="consumption" stroke="#2E7D6B" strokeWidth={2} dot={false} name="Typical" />
                  <ReferenceDot
                    x={`${String(result.input.hour).padStart(2, '0')}:00`}
                    y={result.value}
                    r={6}
                    fill="#D69A2D"
                    stroke="#fff"
                  />
                </LineChart>
              </ResponsiveContainer>
            </ChartCard>
            <ReportButton
              prediction={result}
              model={trainingResult}
              chartElement={chartRef.current}
            />
          </>
        ) : (
          <div className="h-full min-h-[240px] bg-white rounded-lg border border-black/5 border-dashed flex items-center justify-center text-ink/40 text-sm p-6 text-center">
            Fill in the form and click Estimate Consumption to see a result here.
          </div>
        )}
      </div>
    </div>
  )
}
