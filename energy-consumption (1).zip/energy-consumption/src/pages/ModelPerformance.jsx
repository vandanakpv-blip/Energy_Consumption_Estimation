import React from 'react'
import {
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine,
} from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'

export default function ModelPerformance({ trainingResult, modelStatus }) {
  if (modelStatus !== 'ready' || !trainingResult) {
    return (
      <div className="bg-white rounded-lg border border-black/5 p-8 text-center text-ink/50">
        {modelStatus === 'error' ? 'Model training failed. Reload the page to try again.' : 'Training model, results will appear here shortly.'}
      </div>
    )
  }

  const { metrics, trainingSamples, testingSamples, epochs, actualVsPredicted } = trainingResult
  const maxVal = Math.max(...actualVsPredicted.flatMap((d) => [d.actual, d.predicted]), 1) * 1.1

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Model Status" value="Ready" />
        <StatCard label="Training Samples" value={trainingSamples} />
        <StatCard label="Testing Samples" value={testingSamples} />
        <StatCard label="Training Epochs" value={epochs} />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="MAE" value={metrics.mae.toFixed(2)} sublabel="Mean Absolute Error" />
        <StatCard label="MSE" value={metrics.mse.toFixed(2)} sublabel="Mean Squared Error" />
        <StatCard label="RMSE" value={metrics.rmse.toFixed(2)} sublabel="Root Mean Squared Error" />
        <StatCard label="R² Score" value={metrics.r2.toFixed(2)} sublabel="Variance explained" />
      </div>

      <ChartCard title="Actual vs Predicted" description="Points near the diagonal line indicate accurate predictions">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart margin={{ top: 10, right: 20, bottom: 0, left: -10 }}>
            <CartesianGrid stroke="#e8ebe9" />
            <XAxis type="number" dataKey="actual" name="Actual" unit=" kWh" domain={[0, maxVal]} tick={{ fontSize: 11 }} />
            <YAxis type="number" dataKey="predicted" name="Predicted" unit=" kWh" domain={[0, maxVal]} tick={{ fontSize: 11 }} />
            <Tooltip cursor={{ strokeDasharray: '3 3' }} />
            <ReferenceLine segment={[{ x: 0, y: 0 }, { x: maxVal, y: maxVal }]} stroke="#D69A2D" strokeDasharray="4 4" />
            <Scatter data={actualVsPredicted} fill="#2E7D6B" />
          </ScatterChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}
