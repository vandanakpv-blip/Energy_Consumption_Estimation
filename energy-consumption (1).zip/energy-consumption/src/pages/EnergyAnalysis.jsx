import React from 'react'
import {
  LineChart, Line, ScatterChart, Scatter, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary, hourlyAverages, seasonalAverages, trendSeries } from '../services/dataset'

export default function EnergyAnalysis({ rows }) {
  const summary = computeSummary(rows)
  const hourly = hourlyAverages(rows)
  const seasonal = seasonalAverages(rows)
  const trend = trendSeries(rows)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard label="Average Consumption" value={`${summary.averageConsumption.toFixed(2)} kWh`} />
        <StatCard label="Peak Consumption" value={`${summary.highestConsumption.toFixed(2)} kWh`} />
        <StatCard label="Minimum Consumption" value={`${summary.lowestConsumption.toFixed(2)} kWh`} />
        <StatCard label="Average Temperature" value={`${summary.averageTemperature.toFixed(1)}°C`} />
        <StatCard label="Average Humidity" value={`${summary.averageHumidity.toFixed(1)}%`} />
        <StatCard label="Most Common Usage Hour" value={summary.mostCommonHour !== null ? `${String(summary.mostCommonHour).padStart(2, '0')}:00` : '—'} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Hourly Consumption" description="Average consumption by hour of day">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={hourly} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8ebe9" vertical={false} />
              <XAxis dataKey="hour" tick={{ fontSize: 10 }} interval={2} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="consumption" fill="#2E7D6B" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Seasonal Consumption" description="Average consumption by season">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={seasonal} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8ebe9" vertical={false} />
              <XAxis dataKey="season" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="consumption" fill="#D69A2D" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Temperature Relationship" description="Consumption against temperature, every record">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8ebe9" />
              <XAxis type="number" dataKey="temperature" name="Temperature" unit="°C" tick={{ fontSize: 11 }} />
              <YAxis type="number" dataKey="energy_consumption" name="Consumption" unit=" kWh" tick={{ fontSize: 11 }} />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter data={rows} fill="#12203A" />
            </ScatterChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Historical Consumption" description="Recent consumption over time">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trend} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#e8ebe9" vertical={false} />
              <XAxis dataKey="timestamp" tick={{ fontSize: 10 }} interval="preserveStartEnd" />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="consumption" stroke="#2E7D6B" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
