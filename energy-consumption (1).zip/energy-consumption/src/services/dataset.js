import Papa from 'papaparse'

const NUMERIC_FIELDS = [
  'previous_usage',
  'temperature',
  'humidity',
  'hour',
  'day_of_week',
  'previous_period_usage',
  'energy_consumption',
]

const VALID_SEASONS = ['Spring', 'Summer', 'Autumn', 'Winter']

/** Loads and parses the energy dataset shipped with the app. */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/energy_consumption.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Dataset file not found (status ${response.status}). Expected public/data/energy_consumption.csv.`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const rows = parsed.data.filter((row) => {
    return NUMERIC_FIELDS.every((field) => typeof row[field] === 'number' && !Number.isNaN(row[field]))
      && VALID_SEASONS.includes(row.season)
      && (row.holiday === 'Yes' || row.holiday === 'No')
      && typeof row.timestamp === 'string' && row.timestamp.length > 0
  })

  if (rows.length < 30) {
    throw new Error('Dataset has too few valid rows to train a reliable model.')
  }

  return rows
}

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

export function computeSummary(rows) {
  const consumption = rows.map((r) => r.energy_consumption)
  const temps = rows.map((r) => r.temperature)
  const humidity = rows.map((r) => r.humidity)

  const hourCounts = {}
  rows.forEach((r) => { hourCounts[r.hour] = (hourCounts[r.hour] || 0) + 1 })
  const mostCommonHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0]?.[0]

  return {
    totalRecords: rows.length,
    averageConsumption: avg(consumption),
    highestConsumption: Math.max(...consumption),
    lowestConsumption: Math.min(...consumption),
    averageTemperature: avg(temps),
    averageHumidity: avg(humidity),
    mostCommonHour: mostCommonHour ? Number(mostCommonHour) : null,
  }
}

export function hourlyAverages(rows) {
  const buckets = Array.from({ length: 24 }, (_, hour) => ({ hour, total: 0, count: 0 }))
  rows.forEach((r) => {
    buckets[r.hour].total += r.energy_consumption
    buckets[r.hour].count += 1
  })
  return buckets.map((b) => ({
    hour: `${String(b.hour).padStart(2, '0')}:00`,
    consumption: b.count ? Number((b.total / b.count).toFixed(2)) : 0,
  }))
}

export function seasonalAverages(rows) {
  const seasons = ['Spring', 'Summer', 'Autumn', 'Winter']
  return seasons.map((season) => {
    const seasonRows = rows.filter((r) => r.season === season)
    return {
      season,
      consumption: seasonRows.length ? Number(avg(seasonRows.map((r) => r.energy_consumption)).toFixed(2)) : 0,
    }
  })
}

export function trendSeries(rows, maxPoints = 120) {
  const sorted = [...rows].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp))
  const step = Math.max(1, Math.floor(sorted.length / maxPoints))
  return sorted
    .filter((_, i) => i % step === 0)
    .map((r) => ({
      timestamp: r.timestamp.slice(5, 16),
      consumption: r.energy_consumption,
    }))
}
