import React from 'react'

const DAY_LABELS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

export default function PredictionResult({ value, category, input, innerRef }) {
  const meterPct = Math.min(100, (value / 10) * 100)

  const rows = [
    ['Temperature', `${input.temperature}°C`],
    ['Humidity', `${input.humidity}%`],
    ['Hour', `${String(input.hour).padStart(2, '0')}:00`],
    ['Day', DAY_LABELS[input.day_of_week]],
    ['Season', input.season],
    ['Holiday', input.holiday],
    ['Previous Usage', `${input.previous_usage} kWh`],
  ]

  return (
    <div ref={innerRef} className="bg-white rounded-lg border border-black/5 p-6">
      <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Estimated Energy Consumption</p>
      <div className="flex items-end gap-2 mb-1">
        <span className="font-display text-5xl text-ink">{value.toFixed(2)}</span>
        <span className="text-ink/40 text-lg mb-1">kWh</span>
      </div>
      <span
        className="inline-block px-3 py-1 rounded-full text-xs font-medium text-white mb-5"
        style={{ backgroundColor: category.color }}
      >
        {category.label} Usage
      </span>

      <div className="w-full h-2 bg-black/5 rounded-full overflow-hidden mb-6">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${meterPct}%`, backgroundColor: category.color }}
        />
      </div>

      <div className="space-y-2">
        {rows.map(([label, val]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{val}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
