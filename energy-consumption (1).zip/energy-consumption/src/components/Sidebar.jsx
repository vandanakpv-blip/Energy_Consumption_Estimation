import React from 'react'

const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'estimate', label: 'Estimate Consumption' },
  { id: 'analysis', label: 'Energy Analysis' },
  { id: 'model', label: 'Model Performance' },
]

export default function Sidebar({ activePage, onNavigate, open, onClose }) {
  return (
    <>
      {open && <div className="fixed inset-0 bg-black/30 z-20 md:hidden" onClick={onClose} />}
      <aside
        className={`fixed md:sticky top-0 left-0 h-screen w-64 bg-ink text-white flex flex-col z-30 transform transition-transform duration-200 ${
          open ? 'translate-x-0' : '-translate-x-full'
        } md:translate-x-0`}
      >
        <div className="px-6 py-6 border-b border-white/10">
          <p className="font-display text-lg leading-tight">Energy Consumption</p>
          <p className="text-xs text-white/50 mt-1">Estimation &amp; Analytics</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); onClose() }}
              className={`w-full text-left px-3 py-2.5 rounded-md text-sm transition-colors ${
                activePage === item.id
                  ? 'bg-white/10 text-white font-medium'
                  : 'text-white/60 hover:bg-white/5 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="px-6 py-4 border-t border-white/10 text-xs text-white/40">
          Runs entirely in your browser.
          <br />
          No data leaves this page.
        </div>
      </aside>
    </>
  )
}
