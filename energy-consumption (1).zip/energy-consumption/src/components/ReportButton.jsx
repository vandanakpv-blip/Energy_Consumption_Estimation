import React, { useState } from 'react'
import { generatePredictionReportPdf } from '../utils/reportGenerator'

export default function ReportButton({ prediction, model, chartElement }) {
  const [status, setStatus] = useState('idle') // idle | generating | error
  const [error, setError] = useState(null)

  const handleClick = async () => {
    setError(null)
    if (!prediction) {
      setError('Please generate a prediction first.')
      return
    }
    setStatus('generating')
    try {
      await generatePredictionReportPdf({ prediction, model, chartElement })
      setStatus('idle')
    } catch (err) {
      setError(err.message || 'Could not generate the PDF report.')
      setStatus('error')
    }
  }

  return (
    <div>
      <button
        onClick={handleClick}
        disabled={status === 'generating'}
        className="w-full text-sm px-4 py-2.5 rounded-md bg-ink text-white hover:bg-ink/90 transition-colors disabled:opacity-50"
      >
        {status === 'generating' ? 'Generating PDF…' : 'Download Report'}
      </button>
      {error && <p className="text-xs text-red-600 mt-2">{error}</p>}
    </div>
  )
}
