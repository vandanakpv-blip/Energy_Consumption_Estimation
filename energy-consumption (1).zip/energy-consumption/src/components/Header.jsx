import React from 'react'

const TITLES = {
  dashboard: ['Dashboard', 'Energy overview from the loaded dataset'],
  estimate: ['Estimate Consumption', 'Enter conditions to estimate expected energy usage'],
  analysis: ['Energy Analysis', 'Historical patterns across time, temperature, and season'],
  model: ['Model Performance', 'How the trained model scores on held-out records'],
}

export default function Header({ activePage, onMenuClick, modelStatus }) {
  const [title, subtitle] = TITLES[activePage] || ['', '']
  return (
    <header className="sticky top-0 z-10 bg-paper/95 backdrop-blur border-b border-black/5 px-4 md:px-8 py-4 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button className="md:hidden p-2 -ml-2 rounded hover:bg-black/5" onClick={onMenuClick} aria-label="Open navigation">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18M3 12h18M3 18h18" />
          </svg>
        </button>
        <div>
          <h1 className="font-display text-xl md:text-2xl text-ink">{title}</h1>
          <p className="text-sm text-ink/50">{subtitle}</p>
        </div>
      </div>
      <div className="hidden sm:flex items-center gap-2 text-xs px-3 py-1.5 rounded-full bg-white border border-black/5">
        <span
          className={`w-2 h-2 rounded-full ${
            modelStatus === 'ready' ? 'bg-volt' : modelStatus === 'error' ? 'bg-red-500' : 'bg-amber animate-pulse'
          }`}
        />
        <span className="text-ink/60">
          {modelStatus === 'ready' ? 'Model ready' : modelStatus === 'error' ? 'Model error' : 'Preparing model'}
        </span>
      </div>
    </header>
  )
}
