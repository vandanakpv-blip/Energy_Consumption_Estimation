import React from 'react'

export default function StatCard({ label, value, sublabel }) {
  return (
    <div className="bg-white rounded-lg border border-black/5 px-5 py-4">
      <p className="text-xs uppercase tracking-wide text-ink/40">{label}</p>
      <p className="font-display text-2xl text-ink mt-1">{value}</p>
      {sublabel && <p className="text-xs text-ink/40 mt-1">{sublabel}</p>}
    </div>
  )
}
