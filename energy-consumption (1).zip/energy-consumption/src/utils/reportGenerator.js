import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

const APP_NAME = 'Energy Consumption Estimation'

/**
 * Builds and downloads a PDF prediction report.
 * chartElement is an optional DOM node (e.g. a chart card) captured as an
 * image and embedded in the PDF. If capture fails, the report still
 * generates without the chart.
 */
export async function generatePredictionReportPdf({ prediction, model, chartElement }) {
  if (!prediction) {
    throw new Error('Please generate a prediction first.')
  }
  if (!model) {
    throw new Error('Model metrics are not available yet. Wait for training to finish and try again.')
  }

  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const pageWidth = doc.internal.pageSize.getWidth()
  const margin = 48
  let y = margin

  const line = (text, size = 11, weight = 'normal', gap = 16) => {
    doc.setFont('helvetica', weight)
    doc.setFontSize(size)
    doc.text(text, margin, y)
    y += gap
  }

  // Header
  doc.setFillColor(18, 32, 58)
  doc.rect(0, 0, pageWidth, 70, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(18)
  doc.text(APP_NAME, margin, 32)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(10)
  doc.text(`Report generated: ${new Date().toLocaleString()}`, margin, 50)
  doc.setTextColor(18, 32, 58)
  y = 100

  // Prediction details
  line('Prediction Details', 13, 'bold', 20)
  line(`Estimated Consumption: ${prediction.value.toFixed(2)} kWh`)
  line(`Consumption Category: ${prediction.category.label}`)
  y += 8

  // Input details
  line('Input Conditions', 13, 'bold', 20)
  line(`Previous Energy Usage: ${prediction.input.previous_usage} kWh`)
  line(`Temperature: ${prediction.input.temperature} degC`)
  line(`Humidity: ${prediction.input.humidity}%`)
  line(`Hour: ${String(prediction.input.hour).padStart(2, '0')}:00`)
  line(`Day of Week: ${DAY_LABELS[prediction.input.day_of_week]}`)
  line(`Season: ${prediction.input.season}`)
  line(`Holiday: ${prediction.input.holiday}`)
  line(`Previous Period Usage: ${prediction.input.previous_period_usage} kWh`)
  y += 8

  // Model info
  line('Model Information', 13, 'bold', 20)
  line('Model Type: TensorFlow.js feed-forward regression network')
  line(`Training Samples: ${model.trainingSamples}`)
  line(`Testing Samples: ${model.testingSamples}`)
  line(`MAE: ${model.metrics.mae.toFixed(3)}`)
  line(`MSE: ${model.metrics.mse.toFixed(3)}`)
  line(`RMSE: ${model.metrics.rmse.toFixed(3)}`)
  line(`R2 Score: ${model.metrics.r2.toFixed(3)}`)
  y += 8

  // Analysis
  line('Analysis', 13, 'bold', 20)
  const analysis = `The estimated energy consumption for the provided conditions is ${prediction.value.toFixed(2)} kWh. The predicted usage falls within the ${prediction.category.label} consumption range.`
  const wrapped = doc.splitTextToSize(analysis, pageWidth - margin * 2)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(11)
  doc.text(wrapped, margin, y)
  y += wrapped.length * 15 + 10

  // Chart (best effort)
  if (chartElement) {
    try {
      const canvas = await html2canvas(chartElement, { backgroundColor: '#ffffff', scale: 2 })
      const imgData = canvas.toDataURL('image/png')
      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height / canvas.width) * imgWidth

      if (y + imgHeight > doc.internal.pageSize.getHeight() - margin) {
        doc.addPage()
        y = margin
      }
      line('Consumption Chart', 13, 'bold', 20)
      doc.addImage(imgData, 'PNG', margin, y, imgWidth, imgHeight)
      y += imgHeight + 10
    } catch (err) {
      // Chart capture failed — continue without it rather than blocking the report.
      line('Consumption Chart', 13, 'bold', 20)
      doc.setFont('helvetica', 'italic')
      doc.setFontSize(10)
      doc.text('Chart could not be rendered for this report.', margin, y)
      y += 18
    }
  }

  doc.save('energy-consumption-report.pdf')
}

const DAY_LABELS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
