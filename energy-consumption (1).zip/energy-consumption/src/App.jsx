import React, { useEffect, useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import EstimateConsumption from './pages/EstimateConsumption'
import EnergyAnalysis from './pages/EnergyAnalysis'
import ModelPerformance from './pages/ModelPerformance'
import { loadDataset } from './services/dataset'
import { trainModel } from './ml/training'

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const [rows, setRows] = useState(null)
  const [loadStage, setLoadStage] = useState('loading-data') // loading-data | processing | training | evaluating | ready | error
  const [loadError, setLoadError] = useState(null)
  const [progress, setProgress] = useState({ epoch: 0, total: 50 })
  const [trainingResult, setTrainingResult] = useState(null)

  useEffect(() => {
    let cancelled = false

    async function run() {
      try {
        const data = await loadDataset()
        if (cancelled) return
        setLoadStage('processing')
        setRows(data)

        await new Promise((r) => setTimeout(r, 200))
        if (cancelled) return
        setLoadStage('training')

        const result = await trainModel(data, {
          epochs: 50,
          onEpoch: (epoch, total) => {
            if (!cancelled) setProgress({ epoch, total })
          },
        })
        if (cancelled) return

        setLoadStage('evaluating')
        await new Promise((r) => setTimeout(r, 150))
        if (cancelled) return

        setTrainingResult(result)
        setLoadStage('ready')
      } catch (err) {
        if (!cancelled) {
          setLoadError(err.message || 'Something went wrong loading the app.')
          setLoadStage('error')
        }
      }
    }

    run()
    return () => { cancelled = true }
  }, [])

  const modelStatus = loadStage === 'ready' ? 'ready' : loadStage === 'error' ? 'error' : 'loading'

  const STAGE_LABEL = {
    'loading-data': 'Loading Energy Dataset…',
    processing: 'Processing Dataset…',
    training: 'Training ML Model…',
    evaluating: 'Evaluating Model…',
  }

  if (['loading-data', 'processing', 'training', 'evaluating'].includes(loadStage)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm">
          <p className="font-display text-2xl text-ink mb-2">Energy Consumption Estimation</p>
          <p className="text-sm text-ink/50 mb-6">{STAGE_LABEL[loadStage]}</p>
          {loadStage === 'training' && (
            <>
              <div className="w-full h-1.5 bg-black/10 rounded-full overflow-hidden mb-2">
                <div
                  className="h-full bg-volt transition-all duration-150"
                  style={{ width: `${(progress.epoch / progress.total) * 100}%` }}
                />
              </div>
              <p className="text-xs text-ink/40">Epoch {progress.epoch} / {progress.total}</p>
            </>
          )}
        </div>
      </div>
    )
  }

  if (loadStage === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm bg-white border border-black/5 rounded-lg p-6">
          <p className="font-display text-xl text-ink mb-2">Couldn't start the app</p>
          <p className="text-sm text-ink/60">{loadError}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen md:flex">
      <Sidebar activePage={page} onNavigate={setPage} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 min-w-0">
        <Header activePage={page} onMenuClick={() => setSidebarOpen(true)} modelStatus={modelStatus} />
        <main className="p-4 md:p-8">
          {page === 'dashboard' && <Dashboard rows={rows} />}
          {page === 'estimate' && (
            <EstimateConsumption modelStatus={modelStatus} trainingResult={trainingResult} rows={rows} />
          )}
          {page === 'analysis' && <EnergyAnalysis rows={rows} />}
          {page === 'model' && <ModelPerformance modelStatus={modelStatus} trainingResult={trainingResult} />}
        </main>
      </div>
    </div>
  )
}
